# Lab 2 - Important!

Lab 2 part 2 only works from the DIST folder - the version in the src folder got messed up when exporting from codepen.
I plan on not using codepen again in the future

# Lab 2 - 3 

My chrome extension presents a user upon loading every web page with an alert, that asks them if they wish to "make the website interesting"
Clicking Yes transforms all images, headers and links on the page, editing thinks like font size and colour too.
Clicking cancel or dismissing the alert does something similar, but with different content.